//
//  LPPreview3DViewController.m
//  LP_LED_CUBE_8x8x8_IOS
//
//  Created by Luka Penger on 14/11/14.
//  Copyright (c) 2014 Luka Penger. All rights reserved.
//

#import "LPPreview3DViewController.h"


#define BUFFER_OFFSET(i) ((char *)NULL + (i))

typedef struct {
    float Position[3];
    float Color[4];
    float TexCoord[2];
} Vertex;

#define cubeColorR 20.0f
#define cubeColorG 100.0f
#define cubeColorB 255.0f
#define cubeColorA 1.0f

const Vertex Vertices[] = {
    // Front
    {{1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    {{-1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{-1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}},
    // Back
    {{1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{-1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}},
    {{-1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    // Left
    {{-1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{-1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    {{-1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{-1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}},
    // Right
    {{1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    {{1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}},
    // Top
    {{1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    {{-1, 1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{-1, 1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}},
    // Bottom
    {{1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 0}},
    {{1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {1, 1}},
    {{-1, -1, 1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 1}},
    {{-1, -1, -1}, {(cubeColorR/255.0), (cubeColorG/255.0), (cubeColorB/255.0), cubeColorA}, {0, 0}}
};

const GLubyte Indices[] = {
    // Front
    0, 1, 2,
    2, 3, 0,
    // Back
    4, 6, 5,
    4, 5, 7,
    // Left
    8, 9, 10,
    10, 11, 8,
    // Right
    12, 13, 14,
    14, 15, 12,
    // Top
    16, 17, 18,
    18, 19, 16,
    // Bottom
    20, 21, 22,
    22, 23, 20
};


@interface LPPreview3DViewController () {
    GLuint vertexBuffer;
    GLuint indexBuffer;
    
    GLKMatrix4 rotMatrix;
}

@property (nonatomic, strong) EAGLContext *context;
@property (nonatomic, strong) GLKBaseEffect *effect;

@property (nonatomic, strong) NSMutableArray *cubes;

@end


@implementation LPPreview3DViewController

#pragma mark - Lifecycle

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.title = @"3D Preview";
    
    self.view.backgroundColor = [UIColor blackColor];
    
    if (self.backButton) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"BackButton"] style:UIBarButtonItemStyleBordered target:self action:@selector(backButtonClicked)];
    }
    
    if (self.closeButton) {
        self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[UIImage imageNamed:@"CloseButton"] style:UIBarButtonItemStyleBordered target:self action:@selector(closeButtonClicked)];
    }


    self.context = [[EAGLContext alloc] initWithAPI:kEAGLRenderingAPIOpenGLES2];
    if (!self.context) {
        NSLog(@"Failed to create ES context");
    }
    
    GLKView *glkView = (GLKView *)self.view;
    glkView.context = self.context;
    
    // Configure renderbuffers created by the view
    glkView.drawableColorFormat = GLKViewDrawableColorFormatRGBA8888;
    glkView.drawableDepthFormat = GLKViewDrawableDepthFormat16;
    glkView.drawableStencilFormat = GLKViewDrawableStencilFormat8;
    
    // Enable multisampling
    glkView.drawableMultisample = GLKViewDrawableMultisample4X;
    
    [self setupGL];
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];

}

#pragma mark - Actions

- (void)closeButtonClicked
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)backButtonClicked
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - GLKView

- (void)setupGL
{
    [EAGLContext setCurrentContext:self.context];
    
    self.effect = [[GLKBaseEffect alloc] init];

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    
    glGenBuffers(1, &vertexBuffer);
    glBindBuffer(GL_ARRAY_BUFFER, vertexBuffer);
    glBufferData(GL_ARRAY_BUFFER, sizeof(Vertices),
                 Vertices, GL_STATIC_DRAW);
    
    glGenBuffers(1, &indexBuffer);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, indexBuffer);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, sizeof(Indices), Indices, GL_STATIC_DRAW);
    
    glEnableVertexAttribArray(GLKVertexAttribPosition);
    glVertexAttribPointer(GLKVertexAttribPosition, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Position));
    glEnableVertexAttribArray(GLKVertexAttribColor);
    glVertexAttribPointer(GLKVertexAttribColor, 4, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, Color));
    glEnableVertexAttribArray(GLKVertexAttribTexCoord0);
    glVertexAttribPointer(GLKVertexAttribTexCoord0, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), (const GLvoid *) offsetof(Vertex, TexCoord));

    rotMatrix = GLKMatrix4Identity;
    
    
    
    
    UITapGestureRecognizer * dtRec = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(doubleTap:)];
    dtRec.numberOfTapsRequired = 2;
    [self.view addGestureRecognizer:dtRec];
}

#pragma mark - GLKViewDelegate

- (void)glkView:(GLKView *)view drawInRect:(CGRect)rect
{
    glClearColor(0.65f, 0.65f, 0.65f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    [self.effect prepareToDraw];
    
    glDrawElements(GL_TRIANGLES, sizeof(Indices)/sizeof(Indices[0]), GL_UNSIGNED_BYTE, 0);
}

#pragma mark - GLKViewControllerDelegate

-(void)update
{
    float aspect = fabsf(self.view.bounds.size.width / self.view.bounds.size.height);
    GLKMatrix4 projectionMatrix = GLKMatrix4MakePerspective(0.125*(2*M_PI), aspect, 0.1f,100.0f);
    
    self.effect.transform.projectionMatrix = projectionMatrix;
    
    // Compute the model view matrix for the object rendered with GLKit
    GLKMatrix4 scaleMatrix = GLKMatrix4MakeScale(0.5, 0.5, 0.5);
    GLKMatrix4 translateMatrix = GLKMatrix4MakeTranslation(0.0f, 0.0f, -2.0f);
    
    GLKMatrix4 modelMatrix = GLKMatrix4Multiply(translateMatrix, scaleMatrix);
    GLKMatrix4 viewMatrix = GLKMatrix4MakeLookAt(0, 0, 3, 0, 0, 0, 0, 1, 0);
    GLKMatrix4 modelViewMatrix = GLKMatrix4Multiply(viewMatrix, modelMatrix);

    self.effect.transform.modelviewMatrix = modelViewMatrix;
    
    //Rotate by touch
    self.effect.transform.modelviewMatrix = GLKMatrix4Multiply(self.effect.transform.modelviewMatrix, rotMatrix);
}

#pragma mark - Touch events

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    GLKView *glkView = (GLKView *)self.view;
    glkView.context = self.context;
    
    glkView.transform.
    /*
    UITouch * touch = [touches anyObject];
    CGPoint location = [touch locationInView:self.view];
    CGPoint lastLoc = [touch previousLocationInView:self.view];
    CGPoint diff = CGPointMake(lastLoc.x - location.x, lastLoc.y - location.y);
    
    float rotX = -1 * GLKMathDegreesToRadians(diff.y / 2.0);
    float rotY = -1 * GLKMathDegreesToRadians(diff.x / 2.0);
    
    bool isInvertible;
    GLKVector3 xAxis = GLKMatrix4MultiplyVector3(GLKMatrix4Invert(rotMatrix, &isInvertible), GLKVector3Make(1, 0, 0));
    rotMatrix = GLKMatrix4Rotate(rotMatrix, rotX, xAxis.x, xAxis.y, xAxis.z);
    GLKVector3 yAxis = GLKMatrix4MultiplyVector3(GLKMatrix4Invert(rotMatrix, &isInvertible), GLKVector3Make(0, 1, 0));
    rotMatrix = GLKMatrix4Rotate(rotMatrix, rotY, yAxis.x, yAxis.y, yAxis.z);*/
}

- (void)doubleTap:(UITapGestureRecognizer *)tap
{
    rotMatrix = GLKMatrix4Identity;
}

@end
